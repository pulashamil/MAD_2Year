package com.example.user.microelectronic;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class WishList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wish_list);
    }
}
